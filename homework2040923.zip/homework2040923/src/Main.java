import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Доброго времени суток, введите ваше имя : ");
        String name = scanner.nextLine();
        System.out.print(name + ", " + "сколько вам лет? ");
        int age = scanner.nextInt();
        System.out.print("Скажите, пожалуйста, какой у вас вес?");
        double weight = scanner.nextDouble();
        System.out.print("Уважаемый " + name + ", " + "в свои " + age +"лет. Вы для нас дороги, как " + weight + " килограмм чистого золота!!!");
        
    }
}